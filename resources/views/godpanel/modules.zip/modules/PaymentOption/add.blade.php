@extends('godpanel.layouts.layout', ['title' => 'Payment Option'])

@section('css')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<link href="{{asset('assets/libs/nestable2/nestable2.min.css')}}" rel="stylesheet" type="text/css" />
@endsection
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">{{ __('Payment Option') }}</h4>
            </div>
        </div>
        <div class="col-sm-12 text-sm-left">
            @if (\Session::has('success'))
            <div class="alert alert-success">
                <span>{!! \Session::get('success') !!}</span>
            </div>
            @endif
            @if (\Session::has('error_delete'))
            <div class="alert alert-danger">
                <span>{!! \Session::get('error_delete') !!}</span>
            </div>
            @endif
        </div>
    </div>
    <div class="row catalog_box al_catalog_box">
         
        <div class="col-xl-12 col-lg-12 mb-12">
            <div class="card-box h-100">
                <div class="row mb-2">
                    <div class="col-sm-8">
                        <h4 class="page-title">{{ __('Payment Option') }}</h4>
                        <p class="sub-header"></p>
                    </div>
                    <div class="col-sm-4 text-right">
                        <a href="{{route('godpanel.PaymentOption.index')}}" class="btn btn-info waves-effect waves-light text-sm-right " dataid="0">
                            <i class="mdi mdi-plus-circle mr-1"></i> {{ __('View') }}</a>
                         
                    </div>
                </div>
                <form class="row brand-row" enctype="multipart/form-data" method="post" action="{{route('godpanel.PaymentOption.create')}}">
                    @csrf
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 pb-0 mb-0">
                                <div class="row rowYK">
                                    <div class="col-md-12">
                                        <div class="card">
                                           <div class="card-body">
                                              <div class="row">
                                                      <div class="col-md-12">              
                                                                    <label>{{ __("Upload Image") }}</label>
                                                                    <input type="file" accept="image/*" class="dropify" data-plugins="dropify" name="image2" data-default-file="" />
                                                                    <label class="logo-size d-block text-right mt-1">{{ __("Image Size") }} 200x200</label>
                                                    </div>
                                              </div>
                                            </div>
                                         </div> 
                                    </div>
                                      <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Name</label>
                                            <input type="text" name="title" value="" class="form-control" required="">
                                        </div>
                                    </div>  
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Payment Link</label>
                                            <input type="url" name="payment_gateway_link" value="" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Path</label>
                                            <select class="form-control" name="path">
                                                <option value="">COD</option>
                                                @foreach($options as $path)
                                                <option value="{{$path}}">{{$path}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Code</label>
                                            <select class="form-control" name="code">
                                                @foreach($codes as $code)
                                                <option value="{{$code}}">{{$code}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                     
                                     
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="col-sm-12 text-right btn_bottom">
                        <button class="btn btn-info waves-effect waves-light text-sm-right saveBrandOrder">{{ __('Save') }}</button>
                    </div>

             </form>
            </div>
        </div>

      
    </div>
</div>
 
 
@endsection
@section('script')
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src="{{asset('assets/libs/nestable2/nestable2.min.js')}}"></script>
<script src="{{asset('assets/js/pages/my-nestable.init.js')}}"></script>
<script src="{{asset('assets/libs/dragula/dragula.min.js')}}"></script>
<script src="{{asset('assets/js/pages/dragula.init.js')}}"></script>
<script src="{{asset('assets/js/jscolor.js')}}"></script>
<script src="{{ asset('assets/js/jquery.tagsinput-revisited.js') }}"></script>
<link rel="stylesheet" href="{{ asset('assets/css/jquery.tagsinput-revisited.css') }}" />
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>


@include('godpanel.modules.catalog.category-script')
@include('godpanel.modules.catalog.pagescript')
<script type="text/javascript">
 
</script>

@endsection