@extends('godpanel.layouts.layout', ['title' => 'Country'])

@section('css')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<link href="{{asset('assets/libs/nestable2/nestable2.min.css')}}" rel="stylesheet" type="text/css" />
@endsection
@section('content')


<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">{{ __('Subscription Package') }}</h4>
            </div>
        </div>
        <div class="col-sm-12 text-sm-left">
            @if (\Session::has('success'))
            <div class="alert alert-success">
                <span>{!! \Session::get('success') !!}</span>
            </div>
            @endif

            @if (\Session::has('error_delete'))
            <div class="alert alert-danger">
                <span>{!! \Session::get('error_delete') !!}</span>
            </div>
            @endif
        </div>
    </div>
    <div class="row catalog_box al_catalog_box">
         
        <div class="col-xl-12 col-lg-12 mb-12">
            <div class="card-box h-100">
                <div class="row mb-2">
                    <div class="col-sm-8">
                        <h4 class="page-title">{{ __('Subscription Package') }}</h4>
                        <p class="sub-header"></p>
                    </div>
                    <div class="col-sm-4 text-right">
                        <a href="{{route('godpanel.packages.index')}}" class="btn btn-info waves-effect waves-light text-sm-right " dataid="0">
                            <i class="mdi mdi-plus-circle mr-1"></i> {{ __('View') }}</a>
                         
                    </div>
                </div>
                <form class="row brand-row" method="post" action="{{route('godpanel.packages.edit',$package->id)}}">
                    @csrf
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 pb-0 mb-0">
                                <div class="row rowYK">
                                    <div class="col-md-12">
                                        <div class="card">
                                           <div class="card-body">
                                              <div class="row">
                                                     <div class="col-md-6">
                                                          <label>{{ __("Package Type") }}</label>
                                                          <select class="form-control" name="type" required="">
                                                              <option value="Basic" 
                                                              <?= $package->type == "Basic" ? 'selected' : '' ?>>Basic</option>
                                                              <option value="Standard" 
                                                              <?= $package->type == "Standard" ? 'selected' : '' ?>>Standard</option>
                                                              <option value="Advance" 
                                                              <?= $package->type == "Advance" ? 'selected' : '' ?>>Advance</option>
                                                          </select>
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Package Duration") }}</label>
                                                          <select class="form-control" name="duration" required="">
                                                              <option value="monthly"
                                                               <?= $package->duration == "monthly" ? 'selected' : '' ?>>Monthly</option>
                                                              <option value="yearly"
                                                               <?= $package->duration == "yearly" ? 'selected' : '' ?>>Yearly</option>
                                                          </select>
                                                     </div>
                                                      <div class="col-md-12">
                                                          <label>{{ __("Title") }}</label>
                                                          {!! Form::text('title', $package->title, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Description") }}</label>
                                                          {!! Form::text('description', $package->description, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Tagline") }}</label>
                                                          {!! Form::text('tagline', $package->tagline, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>
                                                     <div class="col-md-6">
                                                         <label>{{ __("Actual Price") }}</label>
                                                          
                                                          <input class="form-control" required="required" 
                                                          name="actual_price"
                                                          value="{{$package->actual_price}}" 
                                                          type="number">
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Discounted Price") }}</label>
                                                          {!! Form::text('price', $package->price, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>

                                                     <div class="col-md-6">
                                                          <label>{{ __("Default Member in this package") }}</label>
                                                         
                                                          <input class="form-control" required="required" name="default_member" value="{{$package->default_member}}" type="number">
                                                     </div>

                                                     <div class="col-md-6">
                                                          <label>{{ __("Extra Member Rate (If client adds more) ") }}</label>
                                                       <input class="form-control" required="required" name="extra_per_member_rate" value="{{$package->extra_per_member_rate}}" type="number">
                                                     </div>
                                                     
                                              </div>
                                            </div>
                                         </div> 
                                    </div>
                                     
                                </div>
                            </div>
                            <div class="col-12">
                              <table class="table">
                                <tr>
                                  <th>Sr.no</th>
                                  <th>Features</th>
                                  <th>Yes / No</th>
                                  <th>Duration</th>
                                  <th>Value</th>
                                </tr>
                                @foreach(getPackageFeatures() as $key => $feature)
                                <?php $f = \App\Models\SubscriptionPackageFeature::where('package_id',$package->id)
                                   ->where('type',$feature); ?>
                                 <tr> 
                                  <td>{{$key + 1}}</td>
                                  <td>{{$feature}}</td>
                                  <td>
                                    <select class="form-control" name="has_feature[]" required="">
                                      <option value="">choose</option>
                                      <option 
                                      value="yes" 
                                      <?= $f->count() > 0 && $f->first()->has_feature == 'yes' ? 'selected' : '' ?>>yes</option>
                                      <option 
                                      value="no" 
                                      <?= $f->count() > 0 && $f->first()->has_feature == 'no' ? 'selected' : '' ?>>No</option>
                                    </select>
                                  </td>
                                  <td>
                                    <select class="form-control" name="duration_key[]">
                                      <option value="monthly" <?= $f->count() > 0 && $f->first()->duration == 'monthly' ? 'selected' : '' ?>>monthly</option>
                                      <option value="unlimited" <?= $f->count() > 0 && $f->first()->duration == 'unlimited' ? 'selected' : '' ?>>unlimited</option>
                                    </select>
                                  </td>
                                  <td>
                                    <input type="number" name="duration_value[]" 
                                    value="<?= $f->count() > 0 ? $f->first()->duration_value : '' ?>">
                                  </td>
                                 </tr>
                                @endforeach
                              </table>
                                
                            </div>

                           <div class="col-12">
                            <h4>Template</h4>
                             <table class="table">
                              @foreach($template_records as $temp_id => $template)
                              <tr>
                                <td><img src="{{url($template->image)}}" style="width: 120px;"></td>
                                <th>{{$template->temp_id}}</th>
                                <td>{{$template->name}}</td>
                                <td> 
                                  <input type="checkbox" 
                                    name="templates[]" 
                                    value="<?= $template->temp_id ?>"
                                    <?= count($templates) > 0 && !in_array($template->temp_id,$templates) ? 'checked' : '' ?>
                                    >
                                </td>
                              </tr>
                                     
                              @endforeach
                               
                             </table>
                           </div>





                        </div>
                        
                    </div>
                    <div class="col-sm-12 text-right btn_bottom">
                        <button class="btn btn-info waves-effect waves-light text-sm-right saveBrandOrder">{{ __('Save Package') }}</button>
                    </div>

             </form>
            </div>
        </div>

      
    </div>
</div>
 
 
@endsection
@section('script')
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src="{{asset('assets/libs/nestable2/nestable2.min.js')}}"></script>
<script src="{{asset('assets/js/pages/my-nestable.init.js')}}"></script>
<script src="{{asset('assets/libs/dragula/dragula.min.js')}}"></script>
<script src="{{asset('assets/js/pages/dragula.init.js')}}"></script>
<script src="{{asset('assets/js/jscolor.js')}}"></script>
<script src="{{ asset('assets/js/jquery.tagsinput-revisited.js') }}"></script>
<link rel="stylesheet" href="{{ asset('assets/css/jquery.tagsinput-revisited.css') }}" />
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>


@include('godpanel.modules.catalog.category-script')
@include('godpanel.modules.catalog.pagescript')
<script type="text/javascript">
 
</script>

@endsection