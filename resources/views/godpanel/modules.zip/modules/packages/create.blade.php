@extends('godpanel.layouts.layout', ['title' => 'Country'])

@section('css')
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<link href="{{asset('assets/libs/nestable2/nestable2.min.css')}}" rel="stylesheet" type="text/css" />
@endsection
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">{{ __('Subscription Package') }}</h4>
            </div>
        </div>
        <div class="col-sm-12 text-sm-left">
            @if (\Session::has('success'))
            <div class="alert alert-success">
                <span>{!! \Session::get('success') !!}</span>
            </div>
            @endif

            @if (\Session::has('error_delete'))
            <div class="alert alert-danger">
                <span>{!! \Session::get('error_delete') !!}</span>
            </div>
            @endif
        </div>
    </div>
    <div class="row catalog_box al_catalog_box">
         
        <div class="col-xl-12 col-lg-12 mb-12">
            <div class="card-box h-100">
                <div class="row mb-2">
                    <div class="col-sm-8">
                        <h4 class="page-title">{{ __('Subscription Package') }}</h4>
                        <p class="sub-header"></p>
                    </div>
                    <div class="col-sm-4 text-right">
                        <a href="{{route('godpanel.packages.index')}}" class="btn btn-info waves-effect waves-light text-sm-right " dataid="0">
                            <i class="mdi mdi-plus-circle mr-1"></i> {{ __('View') }}</a>
                         
                    </div>
                </div>
                <form class="row brand-row" method="post" action="{{route('godpanel.packages.create')}}">
                    @csrf
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 pb-0 mb-0">
                                <div class="row rowYK">
                                    <div class="col-md-12">
                                        <div class="card">
                                           <div class="card-body">
                                              <div class="row">
                                                     <div class="col-md-6">
                                                          <label>{{ __("Package Type") }}</label>
                                                          <select class="form-control" name="type" required="">
                                                              <option value="Basic">Basic</option>
                                                              <option value="Standard">Standard</option>
                                                              <option value="Advance">Advance</option>
                                                          </select>
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Package Duration") }}</label>
                                                          <select class="form-control" name="duration" required="">
                                                              <option value="monthly">Monthly</option>
                                                              <option value="yearly">Yearly</option>
                                                          </select>
                                                     </div>
                                                      <div class="col-md-12">
                                                          <label>{{ __("Title") }}</label>
                                                          {!! Form::text('title', null, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Description") }}</label>
                                                          {!! Form::text('description', null, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Tagline") }}</label>
                                                          {!! Form::text('tagline', null, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>
                                                     <div class="col-md-6">
                                                         <label>{{ __("Actual Price") }}</label>
                                                          
                                                          <input class="form-control" required="required" name="actual_price" 
                                                          type="number">
                                                     </div>
                                                     <div class="col-md-6">
                                                          <label>{{ __("Discounted Price") }}</label>
                                                          {!! Form::text('price', null, ['class' => 'form-control', 'required' => 'required']) !!}
                                                     </div>

                                                     <div class="col-md-6">
                                                          <label>{{ __("Default Member in this package") }}</label>
                                                          
                                                          <input class="form-control" required="required" name="default_member" type="number">
                                                     </div>

                                                     <div class="col-md-6">
                                                          <label>{{ __("Extra Member Rate (If client adds more) ") }}</label>
                                                       <input class="form-control" required="required" name="extra_per_member_rate" type="number">
                                                     </div>
                                                     
                                              </div>
                                            </div>
                                         </div> 
                                    </div>
                                     
                                </div>
                            </div>
                        </div>
                        
                    </div>
                     <div class="col-12">
                              <table class="table">
                                <tr>
                                  <th>Sr.no</th>
                                  <th>Features</th>
                                  <th>Yes / No</th>
                                  <th>Duration</th>
                                  <th>Value</th>
                                </tr>
                                @foreach(getPackageFeatures() as $key => $feature)
                             
                                 <tr> 
                                  <td>{{$key + 1}}</td>
                                  <td>{{$feature}}</td>
                                  <td>
                                    <select class="form-control" name="has_feature[]" required="">
                                      <option value="">choose</option>
                                      <option 
                                      value="yes">yes</option>
                                      <option 
                                      value="no">No</option>
                                    </select>
                                  </td>
                                  <td>
                                    <select class="form-control" name="duration_key[]">
                                      <option value="monthly">monthly</option>
                                      <option value="unlimited">unlimited</option>
                                    </select>
                                  </td>
                                  <td>
                                    <input type="number" name="duration_value[]" 
                                    value="">
                                  </td>
                                 </tr>
                                @endforeach
                              </table>
                                
                            </div>

                            <div class="col-12">
                            <h4>Template</h4>
                             <table class="table">
                              @foreach(getTemplates() as $temp_id => $template)
                              <tr>
                                <td><img src="{{$template['image']}}" style="width: 120px;"></td>
                                <th>{{$temp_id}}</th>
                                <td>{{$template['title']}}</td>
                                <td> 
                                  <input type="checkbox" 
                                    name="templates[]" 
                                    value="<?= $temp_id ?>">
                                </td>
                              </tr>
                                     
                              @endforeach
                               
                             </table>
                           </div>
                           
                    <div class="col-sm-12 text-right btn_bottom">
                        <button class="btn btn-info waves-effect waves-light text-sm-right saveBrandOrder">{{ __('Save Package') }}</button>
                    </div>

             </form>
            </div>
        </div>

      
    </div>
</div>
 
 
@endsection
@section('script')
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src="{{asset('assets/libs/nestable2/nestable2.min.js')}}"></script>
<script src="{{asset('assets/js/pages/my-nestable.init.js')}}"></script>
<script src="{{asset('assets/libs/dragula/dragula.min.js')}}"></script>
<script src="{{asset('assets/js/pages/dragula.init.js')}}"></script>
<script src="{{asset('assets/js/jscolor.js')}}"></script>
<script src="{{ asset('assets/js/jquery.tagsinput-revisited.js') }}"></script>
<link rel="stylesheet" href="{{ asset('assets/css/jquery.tagsinput-revisited.css') }}" />
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>


@include('godpanel.modules.catalog.category-script')
@include('godpanel.modules.catalog.pagescript')
<script type="text/javascript">
 
</script>

@endsection