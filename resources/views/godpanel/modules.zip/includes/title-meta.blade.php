

<meta charset="utf-8" />
<title>{{$title ?? ' '}} | <?=  ucfirst($client_head ? $client_head->company_name : '') ?? 'Royo' ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta content="Coderthemes" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- App favicon -->

<link rel="shortcut icon" href="<?= $favicon ?>">