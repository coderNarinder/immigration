
<?php
if (Session::has('toaster')) {
    $toast = Session::get('toaster');
    echo '<script>
            $(document).ready(function(){
                $.NotificationApp.send("' . $toast["title"] . '", "' . $toast["body"] . '", "top-right", "' . $toast["color"] . '", "' . $toast["type"] . '");
            });
        </script>';
}
?>


<script src="{{url('assets/libs/selectize/selectize.min.js')}}"></script>
<script src="{{url('assets/libs/mohithg-switchery/mohithg-switchery.min.js')}}"></script>
<script src="{{url('assets/libs/multiselect/multiselect.min.js')}}"></script>
<script src="{{url('assets/libs/select2/select2.min.js')}}"></script>
<script src="{{url('assets/libs/bootstrap-select/bootstrap-select.min.js')}}"></script>
<script src="{{url('assets/libs/bootstrap-touchspin/bootstrap-touchspin.min.js')}}"></script>
<script src="{{url('assets/libs/sweetalert2/sweetalert2.min.js')}}"></script>
<script src="{{url('assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"></script>
<script src="{{url('assets/libs/flatpickr/flatpickr.min.js')}}"></script>
<script src="{{url('front-assets/js/underscore.min.js')}}"></script>
<script src="{{url('assets/libs/dropzone/dropzone.min.js')}}"></script>
<script src="{{url('assets/libs/dropify/dropify.min.js')}}"></script>
<script src="{{url('front-assets/js/jquery-ui.min.js')}}"></script>
<script src="{{url('assets/libs/bootstrap-colorpicker/bootstrap-colorpicker.min.js')}}"></script>
<script src="{{url('assets/libs/clockpicker/clockpicker.min.js')}}"></script>
<script src="{{url('assets/libs/bootstrap-datepicker/bootstrap-datepicker.min.js')}}"></script>
<script src="{{url('assets/libs/devbridge-autocomplete/devbridge-autocomplete.min.js')}}"></script>
<script src="{{url('assets/js/pages/form-fileuploads.init.js')}}"></script>
<script src="{{url('assets/js/pages/my-form-advanced.init.js')}}"></script>
<script src="{{url('assets/libs/jquery-toast-plugin/jquery-toast-plugin.min.js')}}"></script>
<script src="{{url('assets/js/pages/toastr.init.js')}}"></script>
<script src="{{url('assets/libs/datatables/datatables.min.js')}}"></script>
<script src="https://cdn.socket.io/4.1.2/socket.io.min.js" integrity="sha384-toS6mmwu70G0fw54EGlWWeA4z3dyJ+dlXBtSURSKN4vyRFOcxd3Bzjj/AoOwY+Rg" crossorigin="anonymous"></script>
<script src="https://www.gstatic.com/firebasejs/8.3.2/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.3.2/firebase-messaging.js"></script>
 

@yield('script-bottom')


